import sys
import pysam
'''python get_seq.py res.bed GRCh38.p10.genome.fa'''

fasta = pysam.FastaFile(sys.argv[2])

with open(sys.argv[1]) as f:
    for i in f.readlines():
        line = i.strip().split()
        start,end = line[-2].split(','),line[-1].split(',')
        chr = line[0]
        circ = '%s:%s-%s'%(chr,line[1],line[2])
        seq = []
        for x,y in zip(start,end):
            s = fasta.fetch(chr,int(x),int(y))
            seq.append(s)
        if len(''.join(seq)) < 50:
            print('{}\n{}'.format('>%s'%circ,fasta.fetch(chr, int(line[1]),int(line[2])  )))
        else:
            print('{}\n{}'.format('>%s'%circ,''.join(seq)))
