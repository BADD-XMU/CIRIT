import  sys
'''python anno2.py hg38.genePred test.bed > res.bed'''


def overlap(l1,l2):
    start = max(l1[0],l2[0])
    end = min(l1[1],l2[1])
    if end-start >= 0:
        return [start,end]
    return -1

def inter(lis1,x):
    res = []
    for i in lis1:
        if x[0] <= i[0] <= i[1]<=x[1]:
            res.append(i)
        elif i[0] <= x[0] <=x[1] <=i[1]:
            res.append(x)
        elif i[0] <= x[0] <=i[1] and x[1] >= i[1]:
            res.append([x[0],i[1]])
        elif i[0] <= x[1] <= i[1] and i[0] >= x[0]:
            res.append([i[0], x[1]])
    return  res

def get_anno_bed(file):
    dic = {}
    with open(file) as f:
        for i in f.readlines():
            line = i.strip().split()
            tran, strand , tran_start, tran_end, exon_start, exon_end = line[0], line[2], line[3],line[4], line[8],line[9]
            gene = line[11]
            dic.setdefault(gene, {}).setdefault('strand', strand)
            for x,y in zip(exon_start.rstrip(',').split(','),exon_end.rstrip().split(',')):
                dic.setdefault(gene,{}).setdefault('exon',{}).setdefault(tran,[]).append([int(x),int(y)])
    return dic

def get_index(x,lis):
    for i in range(lis):
        if int(lis[i]) >= int(x):
            return i
    return False

def get_res(file, dic):
    with open(file) as f:
        for i in f.readlines():
            line = i.strip().split()
            start,end,strand,gene = line[1], line[2], line[-1], line[3]
            circ = [int(start),int(end)]
            out = {}
            for x in gene.split(','):
                res = {}
                if x == '---':
                    out.setdefault(1,i.strip() + '\t' + '%s\t%s'%(start,end))
                    continue
                else:

                    for tran in dic[x]['exon'].keys():
                        r = inter(dic[x]['exon'][tran],circ)
                        length = 0
                        for l in r:
                            length += 1
                        res.setdefault(length,r)
                    if res == {0:[]}:
                        out_inter = [[start,end]]
                    else:
                        out_inter = res[max(res.keys())]
                    out.setdefault(len(out_inter),i.strip() + '\t' + ','.join([str(x[0]) for x in out_inter])+'\t'+','.join([str(x[1]) for x in out_inter]))
            print(out[max(out.keys())])
            


# dic = get_anno_bed(r'C:\Users\Administrator\Desktop\cscd2\res\test1.txt')

# get_res(r'C:\Users\Administrator\Desktop\cscd2\res\test.txt',dic)

dic = get_anno_bed(sys.argv[1])

get_res(sys.argv[2],dic)


